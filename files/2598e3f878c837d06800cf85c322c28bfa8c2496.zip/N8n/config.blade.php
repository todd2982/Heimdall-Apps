<h2>{{ __('app.apps.config') }} ({{ __('app.optional') }}) @include('items.enable')</h2>
<div class="items">
    <div class="input">
        <label>{{ strtoupper(__('app.url')) }}</label>
        {!! Form::text('config[override_url]',
            isset($item) ? $item->getconfig()->override_url : null,
            ['placeholder' => __('app.apps.override'),
            'id' => 'override_url',
            'class' => 'form-control'
        ]) !!}
    </div>

    <div class="input">
        <label>{{ __('app.apps.apikey') }}(<a href="https://docs.n8n.io/api/authentication/#create-an-api-key" target="_blank">help?</a>)</label>
        {!! Form::input('password', 'config[password]', '',
            ['placeholder' => __('app.apps.apikey'),
            'data-config' => 'password',
            'class' => 'form-control config-item'
        ]) !!}
    </div>

    <div class="input">
        <button style="margin-top: 32px;" class="btn test" id="test_config">Test</button>
    </div>
</div>
